window.addEventListener('load', getId);
 
async function getId() {
 
    const url = 'http://localhost:3030/jsonstore/advanced/articles/list'
    const res = await fetch(url);
    const data = await res.json();
 
    data.forEach(v => {
        let id = v._id;
        createArticle(id);
    })
 
    show();

}
async function createArticle(id) {
 
    const url = `http://localhost:3030/jsonstore/advanced/articles/details/${id}`
    const res = await fetch(url);
    const data = await res.json();
 
 
    const main = document.getElementById('main')
 
    main.innerHTML = main.innerHTML +
        `   <div class="accordion">
            <div class="head">
                <span>${data.title}</span>
                <button class="button" id=${data._id}>More</button>
            </div>
            <div class="extra">
                <p>${data.content}</p>
            </div>
        </div>`
 
 
}
 
function show() {
    document.getElementById('main').addEventListener('click', onClick);
    
    
    function onClick(e) {
        
    
        const div = e.target.parentNode.parentNode.querySelector('.extra');

        if (div.style.display == 'inline'){
            div.style.display = 'none';
        } else {
            div.style.display = 'inline';
        }
 
        if (e.target.textContent === 'More') {
            
            e.target.textContent = 'Less';
        } else {
            
            e.target.textContent = 'More';
        }
 
    }
}
 

