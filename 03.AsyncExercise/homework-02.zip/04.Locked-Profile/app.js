
function createProfile({ username, email, age }, id) {
    const div = document.createElement('div')
    const button = document.createElement('button')
    button.innerText = 'Show more'

    div.className = 'profile'
    div.innerHTML = `<img src="./iconProfile2.png" class="userIcon">
                          <label>Lock</label>
                          <input type="radio" name="user${id}Locked" value="lock" checked="">
                          <label>Unlock</label>
                          <input type="radio" name="user${id}Locked" value="unlock"><br>
                          <hr>
                          <label>Username</label>
                          <input type="text" name="user${id}Username" value=${username} disabled="" readonly="">
                          <div id="user${id}HiddenFields">
                          <hr>
                          <label>Email:</label>
                          <input type="email" name="user${id}Email" value=${email} disabled="" readonly="">
                          <label>Age:</label>
                          <input type="email" name="user${id}Age" value=${age} disabled="" readonly="">
                          </div>`

    button.addEventListener('click', showMore)

    function showMore(){
        const checked = div.querySelector('input[type=radio]:checked')
        if (checked && checked.value === 'unlock') {
            if (button.innerText === 'Show more') {
                div.querySelector(`#user${id}HiddenFields`).style.display = 'block'
                button.innerText = 'Hide it'
            } else {
                div.querySelector(`#user${id}HiddenFields`).style.display = 'none'
                button.innerText = 'Show more'
            }
        }
    }
    div.appendChild(button);

    return div;
}

async function lockedProfile() {
    const url = 'http://localhost:3030/jsonstore/advanced/profiles';

    const res = await fetch(url);
    const data = await res.json();

    const main = document.querySelector('main');
    main.innerHTML = '';
    

    Object.values(data).forEach((a, b) => main.appendChild(createProfile(a, b)))
}







