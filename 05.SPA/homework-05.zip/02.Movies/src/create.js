import { showView } from "./dom.js";
import { showDetails } from './details.js';
import { showHome } from "./home.js";

const section = document.getElementById('add-movie');
const form = section.querySelector('form');
form.addEventListener('submit', onSubmit);
section.remove();

export function showCreate(){
    showView(section);
}

async function onSubmit(event){
    event.preventDefault();
    const formData = new FormData(event.target);

    const movie = {
        title: formData.get('title'),
        description: formData.get('description'),
        img: formData.get('imageUrl')
    };

    if (movie.title == '' || movie.description == '' || movie.img == '') {
        return alert('All fields must be filled!');
    };

    try {

        const res = await fetch('http://localhost:3030/data/movies', {
        method: 'post',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': JSON.parse(sessionStorage.getItem('userData')).token
        },
        body: JSON.stringify(movie)
    });

    if (res.ok == false) {
        const error = await res.json();
        throw new Error(error.message);
    }
    const movies = await res.json();
    showDetails(movies._id);
    form.reset();
    showHome();c
    
    

    } catch (err) {

        alert(err.message);
    }
}