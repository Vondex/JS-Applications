import { updateNav } from "./app.js";
import { showView } from "./dom.js";
import { showHome } from "./home.js";

const section = document.getElementById('form-sign-up');
const form = section.querySelector('form');
form.addEventListener('submit', onSubmit)
section.remove();

export function showRegister(){
    showView(section);
}

async function onSubmit(event){

    event.preventDefault();
    const formData = new FormData(form);

    const email = formData.get('email').trim();
    const password = formData.get('password').trim();
    const repass = formData.get('repeatPassword').trim();

    if (email == '' || password !== repass || password.length < 6) {
        if (email = '') {
            alert('Enter valid email!')
            throw new Error();
        } else if (password.length < 6) {
            alert('Password must be at least 6 characters!')
            throw new Error();
        } else if (password != repass) {
            alert('Passwords don\'t match!')
            throw new Error();
        }
        showRegister()
    }

    try {
        const res = await fetch('http://localhost:3030/users/register', {
            method: 'post', 
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password, repass })
        });

        if (res.ok == false){
            const error = await res.json();
            throw new Error(error.message);
        }

        const data = await res.json();
        sessionStorage.setItem('userData', JSON.stringify({
            email: data.email,
            id: data._id,
            token: data.accessToken
        }));

        form.reset();
        updateNav();
        showHome();

    } catch (err){

        alert(err.message);
    }
}